import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        benchmark()
    }
    
    func benchmark() {
        let iterations = 10 // Number of iterations for the benchmark
        let modelsCount = 30 // Adjust based on your testing needs
        let waitTime: UInt32 = 1   // Time to wait between operations, in seconds
        
        // Initialize your storage methods
        let fileStorage = SeparatedFileStorage()
        let uniqueStorage = UniqueFileStorage()
        let grdbDequeueStorage = GRDBQueueStorage()
        let grdbPoolStorage = GRDBPoolStorage()
        let grdbDequeueJSONStorage = GRDBQueueJsonStorage()
        let grdbPoolJSONStorage = GRDBPoolJsonStorage()
        let grdbDequeueUniqueJSONStorage = GRDBQueueUniqueJsonStorage()
        let grdbPoolUniqueJSONStorage = GRDBPoolUniqueJsonStorage()
        
        let storages: [(String, Storage)] = [
            ("GRDB Dequeue Relational Storage", grdbDequeueStorage),
            ("GRDB Pool Relational Storage", grdbPoolStorage),
            ("GRDB Queue Separated JSON Storage", grdbDequeueJSONStorage),
            ("GRDB Pool Separated JSON Storage", grdbPoolJSONStorage),
            ("GRDB Queue Unique JSON Storage", grdbDequeueUniqueJSONStorage),
            ("GRDB Pool Unique JSON Storage", grdbPoolUniqueJSONStorage),
            ("Separated File Storage", fileStorage),
            ("Unique File Storage", uniqueStorage)
        ]
        
        storages.forEach { label, storage in
            var storeTimes: [TimeInterval] = []
            var retrieveTimes: [TimeInterval] = []
            var deleteTimes: [TimeInterval] = []
            
            for _ in 1...iterations {
                let models = (1...modelsCount).map { _ in MainModel.random() }
                
                // Store
                let storeStart = Date()
                models.forEach { storage.store(model: $0) }
                let storeElapsed = Date().timeIntervalSince(storeStart)
                storeTimes.append(storeElapsed)
                sleep(waitTime)
                
                // Retrieve
                let retrieveStart = Date()
                models.forEach {
                    guard let _ = storage.retrieve(id: $0.id) else {
                        print("[\(label)] retrieve fail with \($0.id)")
                        return
                    }
                }
                let retrieveElapsed = Date().timeIntervalSince(retrieveStart)
                retrieveTimes.append(retrieveElapsed)
                sleep(waitTime)
                
                // Delete
                let deleteStart = Date()
                models.forEach { storage.remove(id: $0.id) }
                let deleteElapsed = Date().timeIntervalSince(deleteStart)
                deleteTimes.append(deleteElapsed)
            }
            
            // Calculate averages and standard deviations
            let storeAverage = storeTimes.reduce(0, +) / Double(iterations)
            let retrieveAverage = retrieveTimes.reduce(0, +) / Double(iterations)
            let deleteAverage = deleteTimes.reduce(0, +) / Double(iterations)
            
            let storeStdDev = standardDeviation(storeTimes, mean: storeAverage)
            let retrieveStdDev = standardDeviation(retrieveTimes, mean: retrieveAverage)
            let deleteStdDev = standardDeviation(deleteTimes, mean: deleteAverage)
            
            print("\(label) - Store: Avg = \(storeAverage)s, StdDev = \(storeStdDev)")
            print("\(label) - Retrieve: Avg = \(retrieveAverage)s, StdDev = \(retrieveStdDev)")
            print("\(label) - Delete: Avg = \(deleteAverage)s, StdDev = \(deleteStdDev)")
        }
    }
    
    func standardDeviation(_ values: [TimeInterval], mean: TimeInterval) -> TimeInterval {
        let sumOfSquaredDiffs = values.map { pow($0 - mean, 2) }.reduce(0, +)
        return sqrt(sumOfSquaredDiffs / Double(values.count))
    }
}

