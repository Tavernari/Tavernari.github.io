//
//  FileStorage.swift
//  PoC-DB
//
//  Created by Victor C Tavernari on 08/02/2024.
//

import Foundation

struct SeparatedFileStorage: Storage {
    let fileManager = FileManager.default
    let directory: URL
    
    init() {
        directory = fileManager.urls(for: .cachesDirectory, in: .userDomainMask).first!
    }
    
    func store(model: MainModel) {
        DispatchQueue(label: model.id, attributes: .concurrent).async {
            let fileURL = directory.appendingPathComponent("\(model.id).json")
            do {
                let data = try JSONEncoder().encode(model)
                try data.write(to: fileURL)
            } catch {
                print("Error saving model: \(error)")
            }
        }
    }
    
    func retrieve(id: String) -> MainModel? {
        DispatchQueue(label: id, attributes: .concurrent).sync(flags: .barrier) {
            let fileURL = directory.appendingPathComponent("\(id).json")
            do {
                let data = try Data(contentsOf: fileURL)
                let model = try JSONDecoder().decode(MainModel.self, from: data)
                return model
            } catch {
                print("Error retrieving model: \(error)")
                return nil
            }
        }
    }
    
    func remove(id: String) {
        DispatchQueue(label: id, attributes: .concurrent).sync(flags: .barrier) {
            let fileURL = self.directory.appendingPathComponent("\(id).json")
            do {
                try self.fileManager.removeItem(at: fileURL)
            } catch {
                print("Error removing model with id: \(id), error: \(error)")
            }
        }
    }
}

