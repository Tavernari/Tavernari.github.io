//
//  UniqueFileStorage.swift
//  PoC-DB
//
//  Created by Victor C Tavernari on 08/02/2024.
//

import Foundation

struct UniqueFileStorage: Storage {
    static let queue = DispatchQueue.global()
    let fileManager = FileManager.default
    var directory: URL
    private var modelsFileURL: URL
    
    init() {
        directory = fileManager.urls(for: .cachesDirectory, in: .userDomainMask).first!
        modelsFileURL = directory.appendingPathComponent("models.json")
    }
    
    func store(model: MainModel) {
        Self.queue.sync {
            var models = self.readModels()
            models[model.id] = model
            self.writeModels(models)
        }
    }
    
    func retrieve(id: String) -> MainModel? {
        Self.queue.sync {
            return readModels()[id]
        }
    }
    
    func remove(id: String) {
        Self.queue.sync {
            var models = self.readModels()
            models.removeValue(forKey: id)
            self.writeModels(models)
        }
    }
    
    private func readModels() -> [String: MainModel] {
        do {
            let data = try Data(contentsOf: modelsFileURL)
            let models = try JSONDecoder().decode([String: MainModel].self, from: data)
            return models
        } catch {
            print("Fail reading models with error: \(error)")
            return [:]
        }
    }
    
    private func writeModels(_ models: [String: MainModel]) {
        do {
            let data = try JSONEncoder().encode(models)
            try data.write(to: modelsFileURL)
        } catch {
            print("Fail writing models with error: \(error)")
        }
    }
}
