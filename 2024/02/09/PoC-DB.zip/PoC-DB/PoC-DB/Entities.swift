//
//  Entities.swift
//  PoC-DB
//
//  Created by Victor C Tavernari on 08/02/2024.
//

import Foundation

struct AModel: Codable {
    let id: String
    let field: String
}

struct BModel: Codable {
    let id: String
    let field: String
    let fieldC: CModel
}

struct CModel: Codable {
    let id: String
    let field: String
}

struct MainModel: Codable {
    let id: String
    let fieldA: AModel
    let fieldB: BModel
    let fieldC: CModel
}

protocol Storage {
    func store(model: MainModel)
    func retrieve(id: String) -> MainModel?
    func remove(id: String)
}

extension AModel {
    static func random() -> AModel {
        AModel(
            id: UUID().uuidString,
            field: UUID().uuidString
        )
    }
}

extension BModel {
    static func random() -> BModel {
        BModel(
            id: UUID().uuidString,
            field: UUID().uuidString,
            fieldC: .unique()
        )
    }
}

extension CModel {
    
    private static var value: Int = 0
    
    static func unique() -> CModel {
        CModel(
            id: "CmodelID",
            field: "CmodelIDField"
        )
    }
    static func random() -> CModel {
        value += 1
        
        return value % 2 == 0 
        ?
            CModel(
                id: UUID().uuidString,
                field: UUID().uuidString
            )
        :
            .unique()
    }
}

extension MainModel {
    static func random() -> MainModel {
        MainModel(
            id: UUID().uuidString,
            fieldA: .random(),
            fieldB: .random(),
            fieldC: .random())
    }
}
