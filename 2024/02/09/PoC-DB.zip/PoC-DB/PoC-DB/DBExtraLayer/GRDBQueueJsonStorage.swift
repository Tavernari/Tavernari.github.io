//
//  GRDBQueueJsonStorage.swift
//  PoC-DB
//
//  Created by Victor C Tavernari on 09/02/2024.
//

import Foundation
import GRDB

private extension DatabaseQueue {
    /// Initializes a DatabaseQueue with a specified database name.
    /// - Parameter dbName: The name of the database file.
    /// - Returns: An initialized DatabaseQueue, or nil if an error occurs.
    static func setupDatabase(_ dbName: String) -> DatabaseQueue {
        let fileManager = FileManager.default
        let urls = fileManager.urls(for: .cachesDirectory, in: .userDomainMask)
        let documentsURL = urls[urls.endIndex - 1]
        let dbURL = documentsURL.appendingPathComponent(dbName).appendingPathExtension("sqlite")
        
        // Configure database queue
        let dbQueue = try! DatabaseQueue(path: dbURL.path)
        
        do {
            try dbQueue.write { db in
                try db.create(table: "mainModelJSON", ifNotExists: true) { t in
                    t.column("id", .text).primaryKey()
                    t.column("jsonData", .jsonText).notNull()
                }
            }
        } catch {
            print("Failed to create tables: \(error)")
        }
        
        return dbQueue
    }
}

struct GRDBQueueJsonStorage: Storage {
    let dbPool: DatabaseQueue
    
    init(dbPool: DatabaseQueue = .setupDatabase("poc_queue_db_json")) {
        self.dbPool = dbPool
    }
    
    func store(model: MainModel) {
        try? dbPool.write { db in
            let jsonData = try JSONEncoder().encode(model)
            let jsonString = String(data: jsonData, encoding: .utf8) ?? ""
            let insertSQL = "INSERT INTO mainModelJSON (id, jsonData) VALUES (?, ?) ON CONFLICT(id) DO UPDATE SET jsonData = EXCLUDED.jsonData"
            try db.execute(sql: insertSQL, arguments: [model.id, jsonString])
        }
    }
    
    func retrieve(id: String) -> MainModel? {
        do {
            return try dbPool.read { db -> MainModel? in
                let querySQL = "SELECT jsonData FROM mainModelJSON WHERE id = ?"
                let row = try Row.fetchOne(db, sql: querySQL, arguments: [id])
                guard let jsonString = row?["jsonData"] as? String,
                      let jsonData = jsonString.data(using: .utf8) else {
                    return nil
                }
                return try JSONDecoder().decode(MainModel.self, from: jsonData)
            }
        } catch {
            print("Database error: \(error)")
            return nil
        }
    }
    
    func remove(id: String) {
        _ = try? dbPool.write { db in
            try db.execute(sql: "DELETE FROM mainModelJSON WHERE id = ?", arguments: [id])
        }
    }
}
