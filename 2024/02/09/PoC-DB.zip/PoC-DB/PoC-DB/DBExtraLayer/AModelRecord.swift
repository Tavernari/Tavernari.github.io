//
//  AModelRecord.swift
//  PoC-DB
//
//  Created by Victor C Tavernari on 08/02/2024.
//

import Foundation
import GRDB

// Record for AModel
final class AModelRecord: Record {
    var id: String
    var field: String
    
    init(amodel: AModel) {
        self.id = amodel.id
        self.field = amodel.field
        super.init()
    }
    
    required init(row: Row) throws {
        id = row["id"]
        field = row["field"]
        try super.init(row: row)
    }
    
    override func encode(to container: inout PersistenceContainer) {
        container["id"] = id
        container["field"] = field
    }
    
    // Define the table name for this model
    override class var databaseTableName: String {
        return "amodels"
    }
    
    static func createModelTable(db: Database) throws {
        try db.create(table: AModelRecord.databaseTableName, ifNotExists: true) { t in
            t.column("id", .text).primaryKey()
            t.column("field", .text).notNull()
        }
    }
}
