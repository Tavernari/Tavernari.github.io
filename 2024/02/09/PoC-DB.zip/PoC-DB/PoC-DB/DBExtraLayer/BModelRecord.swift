//
//  BModelRecord.swift
//  PoC-DB
//
//  Created by Victor C Tavernari on 08/02/2024.
//

import Foundation
import GRDB

// Record for AModel
final class BModelRecord: Record {
    var id: String
    var field: String
    let fieldCId: String
    
    init(bmodel: BModel, cmodelId: String) {
        self.id = bmodel.id
        self.field = bmodel.field
        self.fieldCId = cmodelId
        super.init()
    }
    
    required init(row: Row) throws {
        id = row["id"]
        field = row["field"]
        fieldCId = row["fieldCId"]
        try super.init(row: row)
    }
    
    override func encode(to container: inout PersistenceContainer) {
        container["id"] = id
        container["field"] = field
        container["fieldCId"] = fieldCId
    }
    
    // Define the table name for this model
    override class var databaseTableName: String {
        return "bmodels"
    }
    
    static func createModelTable(db: Database) throws {
        try db.create(table: BModelRecord.databaseTableName, ifNotExists: true) { t in
            t.column("id", .text).primaryKey()
            t.column("field", .text).notNull()
            t.column("fieldCId", .text).notNull().references(CModelRecord.databaseTableName, onDelete: .cascade)
        }
    }
}

