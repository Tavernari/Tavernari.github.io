//
//  GRDBPoolUniqueJsonStorage.swift
//  PoC-DB
//
//  Created by Victor C Tavernari on 09/02/2024.
//

import Foundation
import GRDB

private extension DatabasePool {
    /// Initializes a DatabaseQueue with a specified database name.
    /// - Parameter dbName: The name of the database file.
    /// - Returns: An initialized DatabaseQueue, or nil if an error occurs.
    static func setupDatabase(_ dbName: String) -> DatabasePool {
        let fileManager = FileManager.default
        let urls = fileManager.urls(for: .cachesDirectory, in: .userDomainMask)
        let documentsURL = urls[urls.endIndex - 1]
        let dbURL = documentsURL.appendingPathComponent(dbName).appendingPathExtension("sqlite")
        
        // Configure database queue
        let dbPool = try! DatabasePool(path: dbURL.path)
        
        do {
            try dbPool.write { db in
                try db.create(table: "mainModelJSON", ifNotExists: true) { t in
                    t.column("id", .text).primaryKey()
                    t.column("jsonData", .jsonText).notNull()
                }
            }
        } catch {
            print("Failed to create tables: \(error)")
        }
        
        return dbPool
    }
}

struct GRDBPoolUniqueJsonStorage: Storage {
    let uniqueId = "unique_json_store" // A constant unique ID for the entire models collection
    let dbQueue: DatabasePool
    
    init(dbQueue: DatabasePool = .setupDatabase("pool_unique_json_db")) {
        self.dbQueue = dbQueue
    }
    
    // Store a single model by updating the dictionary
    func store(model: MainModel) {
        do {
            try dbQueue.write { db in
                var models = self.retrieveAll(db: db) ?? [:]
                models[model.id] = model
                let jsonData = try JSONEncoder().encode(models)
                let jsonString = String(data: jsonData, encoding: .utf8) ?? ""
                let insertSQL = "INSERT INTO mainModelJSON (id, jsonData) VALUES (?, ?) ON CONFLICT(id) DO UPDATE SET jsonData = EXCLUDED.jsonData"
                try db.execute(sql: insertSQL, arguments: [uniqueId, jsonString])
            }
        } catch {
            print("Database error: \(error)")
        }
    }
    
    // Retrieve a single MainModel instance by its ID
    func retrieve(id: String) -> MainModel? {
        do {
            return try dbQueue.read { db in
                let models = self.retrieveAll(db: db)
                return models?[id]
            }
        } catch {
            print("Database error: \(error)")
            return nil
        }
    }
    
    // Remove a single MainModel instance by its ID
    func remove(id: String) {
        do {
            try dbQueue.write { db in
                var models = self.retrieveAll(db: db) ?? [:]
                models.removeValue(forKey: id)
                let jsonData = try JSONEncoder().encode(models)
                let jsonString = String(data: jsonData, encoding: .utf8) ?? ""
                let updateSQL = "UPDATE mainModelJSON SET jsonData = ? WHERE id = ?"
                try db.execute(sql: updateSQL, arguments: [jsonString, uniqueId])
            }
        } catch {
            print("Database error: \(error)")
        }
    }
    
    // Helper method to retrieve the entire dictionary of MainModel instances
    private func retrieveAll(db: Database) -> [String: MainModel]? {
        do {
            let querySQL = "SELECT jsonData FROM mainModelJSON WHERE id = ?"
            if let row = try Row.fetchOne(db, sql: querySQL, arguments: [uniqueId]),
               let jsonString = row["jsonData"] as? String,
               let jsonData = jsonString.data(using: .utf8) {
                return try JSONDecoder().decode([String: MainModel].self, from: jsonData)
            }
        } catch {
            print("Error retrieving models: \(error)")
        }
        return nil
    }
}

