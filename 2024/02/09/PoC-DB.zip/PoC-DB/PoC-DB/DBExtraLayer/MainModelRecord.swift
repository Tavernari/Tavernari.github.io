//
//  MainModelRecord.swift
//  PoC-DB
//
//  Created by Victor C Tavernari on 08/02/2024.
//

import Foundation
import GRDB

final class MainModelRecord: Record {
    var id: String
    var fieldAid: String
    var fieldBid: String
    var fieldCid: String
    
    init(model: MainModel) {
        self.id = model.id
        self.fieldAid = model.fieldA.id
        self.fieldBid = model.fieldB.id
        self.fieldCid = model.fieldC.id
        super.init()
    }
    
    required init(row: Row) throws {
        id = row["id"]
        fieldAid = row["fieldAid"]
        fieldBid = row["fieldBid"]
        fieldCid = row["fieldCid"]
        try super.init(row: row)
    }
    
    override func encode(to container: inout PersistenceContainer) {
        container["id"] = id
        container["fieldAid"] = fieldAid
        container["fieldBid"] = fieldBid
        container["fieldCid"] = fieldCid
    }
    
    // Define the table name for this model
    override class var databaseTableName: String {
        return "mainmodels"
    }
    
    static func createModelTable(db: Database) throws {
        try db.create(table: MainModelRecord.databaseTableName, ifNotExists: true) { t in
            t.column("id", .text).primaryKey()
            t.column("fieldAid", .text).notNull().references(AModelRecord.databaseTableName, onDelete: .cascade)
            t.column("fieldBid", .text).notNull().references(BModelRecord.databaseTableName, onDelete: .cascade)
            t.column("fieldCid", .text).notNull().references(CModelRecord.databaseTableName, onDelete: .cascade)
        }
    }
}
