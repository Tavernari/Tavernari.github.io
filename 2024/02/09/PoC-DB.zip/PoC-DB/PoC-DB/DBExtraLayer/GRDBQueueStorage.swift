//
//  GRDBQueueStorage.swift
//  PoC-DB
//
//  Created by Victor C Tavernari on 08/02/2024.
//

import Foundation
import GRDB

private extension DatabaseQueue {
    /// Initializes a DatabaseQueue with a specified database name.
    /// - Parameter dbName: The name of the database file.
    /// - Returns: An initialized DatabaseQueue, or nil if an error occurs.
    static func setupDatabase(_ dbName: String) -> DatabaseQueue {
        let fileManager = FileManager.default
        let urls = fileManager.urls(for: .cachesDirectory, in: .userDomainMask)
        let documentsURL = urls[urls.endIndex - 1]
        let dbURL = documentsURL.appendingPathComponent(dbName).appendingPathExtension("sqlite")
        
        // Configure database queue
        let dbQueue = try! DatabaseQueue(path: dbURL.path)
        
        do {
            try dbQueue.write { db in
                try AModelRecord.createModelTable(db: db)
                try CModelRecord.createModelTable(db: db)
                try BModelRecord.createModelTable(db: db)
                try MainModelRecord.createModelTable(db: db)
            }
        } catch {
            print("Failed to create tables: \(error)")
        }
        
        return dbQueue
    }
}


struct GRDBQueueStorage: Storage {
    let dbQueue: DatabaseQueue
    
    init(dbQueue: DatabaseQueue = .setupDatabase("poc_queue_db")) {
        self.dbQueue = dbQueue
        
        do {
            try dbQueue.write { db in
                // Create tables for each model
                try MainModelRecord.createModelTable(db: db)
                try AModelRecord.createModelTable(db: db)
                try BModelRecord.createModelTable(db: db)
                try CModelRecord.createModelTable(db: db)
            }
        } catch {
            print("Failed to create tables: \(error)")
        }
    }
    
    func store(model: MainModel) {
        // Example for storing AModel part of MainModel
        try? dbQueue.write { db in
            try AModelRecord(amodel: model.fieldA).save(db)
            try [model.fieldC, model.fieldB.fieldC].forEach { cmodel in
                try CModelRecord(model: cmodel).save(db)
            }
            try BModelRecord(bmodel: model.fieldB, cmodelId: model.fieldB.fieldC.id).save(db)
            try MainModelRecord(model: model).save(db)
        }
    }
    
    func retrieve(id: String) -> MainModel? {
        do {
            return try dbQueue.read { db -> MainModel? in
                guard let mainModelRecord = try MainModelRecord.fetchOne(db, key: ["id": id]) else { return nil }
                
                // Fetch AModel
                guard let aModelRecord = try AModelRecord.fetchOne(db, key: ["id": mainModelRecord.fieldAid]) else { return nil }
                let aModel = AModel(id: aModelRecord.id, field: aModelRecord.field)
                
                // Fetch BModel and its related CModel
                guard let bModelRecord = try BModelRecord.fetchOne(db, key: ["id": mainModelRecord.fieldBid]),
                      let cModelForBRecord = try CModelRecord.fetchOne(db, key: ["id": bModelRecord.fieldCId]) else { return nil }
                let cModelForB = CModel(id: cModelForBRecord.id, field: cModelForBRecord.field)
                let bModel = BModel(id: bModelRecord.id, field: bModelRecord.field, fieldC: cModelForB)
                
                // Fetch CModel directly associated with MainModel
                guard let cModelRecord = try CModelRecord.fetchOne(db, key: ["id": mainModelRecord.fieldCid]) else { return nil }
                let cModel = CModel(id: cModelRecord.id, field: cModelRecord.field)
                
                return MainModel(id: mainModelRecord.id, fieldA: aModel, fieldB: bModel, fieldC: cModel)
            }
        } catch {
            print("Database error: \(error)")
            return nil
        }
    }
    
    func remove(id: String) {
        _ = try? dbQueue.write { db in
            if let mainModelRecord = try MainModelRecord.fetchOne(db, key: ["id": id]) {
                // Delete related AModel, BModel, and CModel records
                try AModelRecord.deleteOne(db, key: ["id": mainModelRecord.fieldAid])
                try BModelRecord.deleteOne(db, key: ["id": mainModelRecord.fieldBid])
                try CModelRecord.deleteOne(db, key: ["id": mainModelRecord.fieldCid])
            }
            try MainModelRecord.deleteOne(db, key: ["id": id])
        }
    }

}
