//
//  CModelRecord.swift
//  PoC-DB
//
//  Created by Victor C Tavernari on 08/02/2024.
//

import Foundation
import GRDB

// Record for AModel
final class CModelRecord: Record {
    var id: String
    var field: String
    
    init(model: CModel) {
        self.id = model.id
        self.field = model.field
        super.init()
    }
    
    required init(row: Row) throws {
        id = row["id"]
        field = row["field"]
        try super.init(row: row)
    }
    
    override func encode(to container: inout PersistenceContainer) {
        container["id"] = id
        container["field"] = field
    }
    
    // Define the table name for this model
    override class var databaseTableName: String {
        return "cmodels"
    }
    
    static func createModelTable(db: Database) throws {
        try db.create(table: CModelRecord.databaseTableName, ifNotExists: true) { t in
            t.column("id", .text).primaryKey()
            t.column("field", .text).notNull()
        }
    }
}

